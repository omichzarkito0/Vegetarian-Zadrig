<cuerpo>

	<div class="container margin-top-20px">

		<div class="row">
			
			<div class="col-md-4">

				<div class="col-sm-12">
					<div class="row">
						<div class="efect-hover-key">

							<div class="col-sm-12">
								<img class="img-90-porciento" src="./imagenes/ellerburger.jpg"/>
							</div>

							<div class="div-90x100-porciento">
								<div class="efect-hover">
									<button>Ver Información Nutricional</button>
								</div>
							</div>

						</div>
					</div>
				</div>

				<div class="col-sm-12">
					<div class="col-sm-12 ordenar">

						<button onclick="detailsOpen(0);">DETALLES</button>
						<button ng-click="agregarEspecialidad('Eller Burger');">ORDENA AQUÍ</button>

					</div>
				</div>

			</div>

		</div>		
		
	</div>

</cuerpo>