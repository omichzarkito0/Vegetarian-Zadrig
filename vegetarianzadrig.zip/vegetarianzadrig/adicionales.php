<cuerpo>

	<div class="container margin-top-20px">

		<div class="row">
			
			<div class="col-md-4">

				<div class="col-sm-12">
					<div class="row">
						<div class="efect-hover-key">

							<div class="col-sm-12">
								<img class="img-90-porciento" src="./imagenes/ceviche.jpg"/>
							</div>

							<div class="div-90x100-porciento">
								<div class="efect-hover">
									<button>Ver Información Nutricional</button>
								</div>
							</div>

						</div>
					</div>
				</div>

				<div class="col-sm-12">
					<div class="col-sm-12 ordenar">

						<button ng-click="agregarAdicional('1/2 Litro Ceviche');">1/2 Litro<br>(ORDENA AQUÍ)</button>
						<button ng-click="agregarAdicional('1 Litro Ceviche');">1 Litro<br>(ORDENA AQUÍ)</button>

					</div>
				</div>

			</div>

		</div>		
		
	</div>
</cuerpo>