
<footer>
	<div class="container">
		<div class="row">

			<div class="col-md-3 col-sm-12">
				<h3>Contactanos</h3>
				<p>(+52) 312 123 1332</p>
				<p>support@vegetarianzadrig.com.mx</p>
			</div>

			<div class="col-md-9 col-sm-12">
				<div class="row">
					
					<div class="col-md-6 col-sm-12">
						<h3>Quienes Somos..</h3>
						<p class="text-family-alegreya">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					</div>

					<div class="col-md-6 col-sm-12">
						<h3 class="text-center">Siguenos en</h3>
						<div class="row margin-top-20px">
							
							<div class="col-sm-4 col-4">
								<a href="https://web.facebook.com/Vegetarian-Zadrig-109969603819160/"><img src="./imagenes/facebook.png" class="redes"></a>
							</div>

							<div class="col-sm-4 col-4">
								<a href="#"><img src="./imagenes/twitter.png" class="redes"></a>
							</div>

							<div class="col-sm-4 col-4">
								<a href="#"><img src="./imagenes/instagram.png" class="redes"></a>
							</div>

						</div>
					</div>

				</div>
			</div>
		
		</div>
	</div>
</footer>